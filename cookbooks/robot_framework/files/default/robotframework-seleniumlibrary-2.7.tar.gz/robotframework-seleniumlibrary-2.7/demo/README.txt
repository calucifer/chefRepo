Robot Framework SeleniumLibrary Demo
------------------------------------

This directory contains an easily executable demo for Robot Framework
using SeleniumLibrary. The tests can be executed using the `rundemo.py`
script. Full usage instructions are available online at
http://code.google.com/p/robotframework-seleniumlibrary/wiki/Demo

