module <%= controller_class_name %>Helper
end
