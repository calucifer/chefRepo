require 'test_helper'

class <%= class_name %>HelperTest < ActionView::TestCase
end
