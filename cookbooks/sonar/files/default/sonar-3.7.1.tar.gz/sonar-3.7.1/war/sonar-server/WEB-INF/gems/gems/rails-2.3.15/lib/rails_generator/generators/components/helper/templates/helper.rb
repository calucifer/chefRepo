module <%= class_name %>Helper
end
