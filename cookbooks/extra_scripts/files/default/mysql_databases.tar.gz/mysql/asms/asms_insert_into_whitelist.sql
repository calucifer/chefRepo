/*
-- Query: SELECT * FROM asms.whitelist
-- Date: 2012-08-14 16:53
*/
use asms;

INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (1,'RTX','2012-07-16 15:19:42');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (2,'ASMS-UI','2012-07-18 14:36:10');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (3,'RTX','2012-08-14 16:52:45');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (4,'ATX','2012-08-14 16:52:45');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (5,'UTS-API','2012-08-14 16:52:45');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (6,'INGESTOR','2012-08-14 16:52:45');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (7,'TRS','2012-08-14 16:52:45');
INSERT INTO `whitelist` (`whitelistId`,`application`,`lastModified`) VALUES (8,'FTP-RETRIEVER','2012-08-14 16:52:45');
